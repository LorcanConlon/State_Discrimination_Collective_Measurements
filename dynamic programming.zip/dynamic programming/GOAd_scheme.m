clear all
close all

vvec=[0,0.1,0.3];
for vv=1:length(vvec);
v=vvec(vv);
alpha=pi/4;
%defines the state
Pn=0.5;
%initial prior
nphi=100;
%how many phis do you want to use


Nfin=6;

%calculate Helstrom bound
for ll=1:Nfin
    
    Helstrom_error(ll)=helstrom(rhoplus(v,alpha),rhominus(v,alpha),Pn,ll);
end
phivec=linspace(0,pi/2,nphi);

%this is how many different error probabilities and angles we will iterate over.
%Higgins used ~ 50
nsamp=100;
eps=0.0001;
PerrVec=linspace(0+eps,1-eps,nsamp);
anglevec=linspace(0+eps,pi/2-eps,nsamp);

%this is the repeating table of error probabilities on run to run
Ertable=[];
%Ertable=[PerrVec',PerrVec',PerrVec'];
%table of optimal angles
angletable=0*Ertable;

%this is the actual table of how well the estimation scheme does
ActualErtable=0*Ertable;

%GLOBALLY OPTIMAL ADAOTIVE MEASUREMENT

minvalvec=[]
for kk =1:Nfin
    %want to optimise each phi value
    Ertable=[Ertable,PerrVec'];
    if kk==1
        %n the first round the optimal angle for each Perr is just the
        %Helstrom angle
        for hh=1:length(PerrVec)
            errorProb=PerrVec(hh);
            optimalangle=0.5*acot((2*errorProb-1)*cot(alpha));
            anglevecopt(hh)=optimalangle;
            erInt=errorProb*trace(Pi1(optimalangle)*rhoplus(v,alpha))+(1-errorProb)*trace(Pi0(optimalangle)*rhominus(v,alpha));
            Perror_firstrun(hh)=min(erInt,1-erInt);
        end
        angletable=[anglevecopt',angletable];
        ActualErtable=[Perror_firstrun',ActualErtable];
        
        %for each angle we also want to do the optimisation for
        %errorProb=Pn, so that we can extract the 
        
        errorProb=Pn;
        optimalangle=0.5*acot((2*errorProb-1)*cot(alpha));
        Perror_out(kk)=errorProb*trace(Pi1(optimalangle)*rhoplus(v,alpha))+(1-errorProb)*trace(Pi0(optimalangle)*rhominus(v,alpha));

    elseif kk~=Nfin
        %just first getting the value if we have this many copies
        errorProb=Pn;
        for ll=1:length(anglevec)
             phiin=anglevec(ll);
             valuesave(ll)=R_recursive_GOAd(phiin,v,alpha,errorProb,678,0,kk,angletable,PerrVec);
        end
        [minval_opt,indexx]=min(valuesave);
        Perror_out(kk)=minval_opt;
        
        for hh=1:length(PerrVec)
            errorProb=PerrVec(hh);
            for ll=1:length(anglevec)
                phiin=anglevec(ll);
                %valuesave(hh)=R_recursive(phiin,phiknown,v,alpha,Pn,233424234,0,kk);
                valuesave(ll)=R_recursive_GOAd(phiin,v,alpha,errorProb,678,0,kk,angletable,PerrVec);
            end
            %for each error probability in the table, we want the angle
            %which minimises this
            [minval_opt,indexx]=min(valuesave);
            anglevecopt(hh)=anglevec(indexx);
            Perror_nthrun(hh)=minval_opt;
        end
        angletable=[anglevecopt',angletable];
        ActualErtable=[Perror_nthrun',ActualErtable];
        
        
    elseif kk==Nfin
        %now we only optimise over the known input error probability
            errorProb=Pn;
            for ll=1:length(anglevec)
                phiin=anglevec(ll);
                %valuesave(hh)=R_recursive(phiin,phiknown,v,alpha,Pn,233424234,0,kk);
                valuesave(ll)=R_recursive_GOAd(phiin,v,alpha,errorProb,678,0,kk,angletable,PerrVec);
            end
            %for each error probability in the table, we want the angle
            %which minimises this
            [minval_opt,indexx]=min(valuesave);
            %anglevecopt(hh)=anglevec(indexx);
            Perror_nthrun(hh)=minval_opt;
        Perrorfin_GOAd=minval_opt
        Perror_out(kk)=minval_opt;
        %angletable=[anglevecopt',angletable];
        %ActualErtable=[Perror_nthrun',ActualErtable];
        
%         [rout,phivec]= R_recursive_GOAd_phi_extraction(phiin,v,alpha,errorProb,678,0,2,angletable,PerrVec,[]);
       
    end
    

end
figure(vv) 
plot(Perror_out)
hold on
plot(real(Helstrom_error),'-o')
set(gca,'yscale','log')

% below we can numerically search for GOA measurements for small N; just
% to confirm we are correcttumondo

%below just printing the optimal angles, so we can work out why down below
%n'est pas working. Okay yes not working becasue for 2 copy estimation you
%need 3 different angles. I suspect for pi/4 angle between the states, only
%2 angles are needed cos of symmetry. But apparently not
%rout= R_recursive_GOAd_phi_extraction(anglevec(indexx),v,alpha,Pn,678,0,2,angletable,PerrVec,phiin);

%%
    for kk =1:length(phivec)
        kk;
        phiin1=anglevec(kk);
        
        valuesave1(kk)=R_recursive_manual(phiin1,v,alpha,Pn,233424234,0,2);
    for gg =1:length(phivec)
        
        phiin2=anglevec(gg);
        
        %want to optimise each phi value
         for hh=1:length(phivec)
             phiin3=anglevec(hh);
%     % %         for ii=1:length(phivec)
    %             phiin3=phivec(ii);
    %             for jj=1:length(phivec)
    %                 phiin4=phivec(jj);
                    phiintot=[phiin1,phiin2,phiin3];
                        valuesave2(kk,gg,hh)=R_recursive_manual(phiintot,v,alpha,Pn,233424234,0,3);
      %           end

            %end
         end
    end
    end

 
yline( min(min(min(valuesave2))))

yline( min(valuesave1))
end


%what if we do optimal single copy measurement many times / optimal
%helstrom measurement at each step ? 