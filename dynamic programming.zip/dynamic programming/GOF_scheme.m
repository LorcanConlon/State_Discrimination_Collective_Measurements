clear all
close all

vvec=[0,0.02,0.1,0.3,0.6];

for lm=1:length(vvec)
fprintf(2,'run no %g, visibility = %g \n',lm,vvec(lm))
v=vvec(lm);
alpha=pi/6;
%defines the state
Pn=0.5;
%initial prior
nphi=1000;
%how many phis do you want to use

M0p=Pn*rhoplus(v,alpha)-(1-Pn)*rhominus(v,alpha);

rhoplus2=kron(rhoplus(v,alpha),rhoplus(v,alpha));
rhominus2=kron(rhominus(v,alpha),rhominus(v,alpha));
M0p2=Pn*rhoplus2-(1-Pn)*rhominus2;

Pe1Helstrom=0.5*(1-trace(sqrtm(M0p*M0p')))
Pe2Helstrom=0.5*(1-trace(sqrtm(M0p2*M0p2')))

phivec=linspace(0,pi/2,nphi);


Nfin=10;

%GLOBALLY OPTIMAL FIXED LOCAL MEASUREMENT
%initial phiknown is just random but after we will build it up

minvalvec=[];
for kk =1:Nfin
    %want to optimise each phi value
    for hh=1:length(phivec)
        phiin=phivec(hh);
        %valuesave(hh)=R_recursive(phiin,phiknown,v,alpha,Pn,233424234,0,kk);
        valuesave(hh)=R_recursive_GOF(phiin,v,alpha,Pn,678,0,kk);
    end
    
    [minval,opth]=min(valuesave);
    
%     if kk==1
%         phiknown=phivec(opth);
%     else
%         phiknown=[phivec(opth),phiknown];
%     end
phisave(kk)=phivec(opth);
    minvalvec(kk)=minval;
    
%     plot(phivec,valuesave)
%     yline(Pe1Helstrom)
%     return
end
minvalvec;

for kk=1:length(phisave)
   if phisave(kk)<pi/4 
      phisave(kk)=pi/2-phisave(kk) ;
   end
end
figure(1)
hold on
plot(phisave)

figure(2)
hold on
plot(minvalvec)
set(gca,'Yscale','log')
end
