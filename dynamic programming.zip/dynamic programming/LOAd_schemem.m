clear all
close all
vvec=linspace(0.01,0.99,20);
for vv =1:length(vvec)
    v=vvec(vv);
    alpha=pi/6;
    %defines the state
    Pn=0.5;
    %initial prior
    nphi=1000;
    %how many phis do you want to use

    M0p=Pn*rhoplus(v,alpha)-(1-Pn)*rhominus(v,alpha);

    rhoplus2=kron(rhoplus(v,alpha),rhoplus(v,alpha));
    rhominus2=kron(rhominus(v,alpha),rhominus(v,alpha));
    M0p2=Pn*rhoplus2-(1-Pn)*rhominus2;

    Pe1Helstrom=0.5*(1-trace(sqrtm(M0p*M0p')));
    Pe2Helstrom=0.5*(1-trace(sqrtm(M0p2*M0p2')));

    phivec=linspace(0,pi/2,nphi);

    %just checking this matches up with MM
    % for kk=1:length(phivec)
    %     phi=phivec(kk);
    %     probvec(kk)=pmeasDstatep(phi,v,alpha,0);
    % end
    % plot(phivec,probvec)

    Nfin=2;

    %LOCALLY OPTIMAL ADAPTIVE MEASUREMENT
    %using eq(4) of Higgins, we can get the optimal measurement given a certain
    %prior. (For pure states this should equal the Helstrom bound. Also appears to equal the Helstrom bound for mixed states)
    phiivec=[]
    for kk=1:Nfin

    %     phi=0.5*acot((2*q-1)*cot(alpha));
    %     phiivec=[phiivec,phi];
        %don't need to optimise the phi's in each stage, but we do need a new
        %recursive function which has a different phi value for each step
        Perror_local_adaptive(kk)=R_recursive_LOF(phiivec,v,alpha,Pn,678,0,kk);

    end
   Psave(vv)=Perror_local_adaptive(Nfin);
   Helstromsave(vv)=Pe2Helstrom;
end

plot(vvec,Helstromsave)
hold on
plot(vvec,Psave,'.')

figure(2)
plot(vvec,Helstromsave-Psave,'.')