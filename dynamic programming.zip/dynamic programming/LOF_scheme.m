clear all
close all
vvec=[0,0.02,0.1,0.3,0.6];
Nfintot=10;
for lm=1:length(vvec)
    fprintf(2,'run no %g, visibility = %g \n',lm,vvec(lm))
    v=vvec(lm);
    alpha=pi/6;
    %defines the state
    Pn=0.5;
    %initial prior
    nphi=1000;
    %how many phis do you want to use

    M0p=Pn*rhoplus(v,alpha)-(1-Pn)*rhominus(v,alpha);

    rhoplus2=kron(rhoplus(v,alpha),rhoplus(v,alpha));
    rhominus2=kron(rhominus(v,alpha),rhominus(v,alpha));
    M0p2=Pn*rhoplus2-(1-Pn)*rhominus2;

    Pe1Helstrom=0.5*(1-trace(sqrtm(M0p*M0p')))
    Pe2Helstrom=0.5*(1-trace(sqrtm(M0p2*M0p2')))

    phivec=linspace(0,pi/2,nphi);

    %just checking this matches up with MM
    % for kk=1:length(phivec)
    %     phi=phivec(kk);
    %     probvec(kk)=pmeasDstatep(phi,v,alpha,0);
    % end
    % plot(phivec,probvec)

    

    %LOCALLY OPTIMAL FIXED LOCAL MEASUREMENT
    %we find the phi which minimises the single copy P.O.E., then repeatedly
    %use that
    for kk=1:length(phivec) 
        phi=phivec(kk);
        Perror(kk)=Pn*trace(Pi1(phi)*rhoplus(v,alpha))+(1-Pn)*trace(Pi0(phi)*rhominus(v,alpha));

    end
    Perrorlocal=min(Perror);
    
     for Nfin=1:Nfintot
        Nfineff=Nfin;
        %for fixed local measurements an even number of copies performs identical
        %to an uneven no

        if ~mod(Nfin,2)
            Nfineff=Nfin-1;
        end
        Perrlocal_local=0;
        for n=0:floor(Nfineff/2)
            Perrlocal_local=Perrlocal_local+nchoosek(Nfineff,n)*(1-Perrorlocal)^n*(Perrorlocal)^(Nfineff-n);
        end
        PerrN(Nfin)=Perrlocal_local;
     end
      
     plot(PerrN)
     hold on
    
end
set(gca,'Yscale','log')
