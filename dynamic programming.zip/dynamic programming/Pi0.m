function povm=Pi0(phi)

meas=cos(phi)*[1,0]+sin(phi)*[0,1];
povm=meas'*meas;