function povm=Pi1(phi)

meas=cos(phi)*[1,0]+sin(phi)*[0,1];
povm=eye(2)-meas'*meas;