function rout= R_recursive(phiin,phiknown,v,alpha,Pn,D,n,Nfin)

%phivec is a list of phi values, it is what we are optimising each step
%over

%phiknown is a list of known phi values, e.g. if we are doing 4 step
%optimisation and we already have two of the known angles

%v, alpha, Pn are parameters of the model

% D is the detection outcome; either 0 or 1

% n is the current stage

% Nfin is maximum number of stages

%assumes we always start at n=0, i.e. we are always using Higgins notation
%and calculating R0
  
if n==Nfin    
    %for kk=0:1
      %
        rout=min(Pn,1-Pn);
        
    %end
% elseif n~=0
%     
%     phi=phiknown(n);
%     Pnext0=pnplus1(phi,v,alpha,0,Pn);
%     Pnext1=pnplus1(phi,v,alpha,1,Pn);
%     
%     rout= pmeasDstatem(phi,v,alpha,0)*R_recursive(phi,phiknown,v,alpha,Pnext0,0,n+1,Nfin)+ pmeasDstatem(phi,v,alpha,1)*R_recursive(phi,phiknown,v,alpha,Pnext1,1,n+1,Nfin);
% elseif n==0
else
   %want to optimise phi in here
   phi=phiin;
    Pnext0=pnplus1(phi,v,alpha,0,Pn);
    Pnext1=pnplus1(phi,v,alpha,1,Pn);
    
    rout= probD(phi,v,alpha,0,Pn)*R_recursive(phi,phiknown,v,alpha,Pnext0,0,n+1,Nfin)+ probD(phi,v,alpha,1,Pn)*R_recursive(phi,phiknown,v,alpha,Pnext1,1,n+1,Nfin);

end
    
end