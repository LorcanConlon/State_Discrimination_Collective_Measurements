function [rout]= R_recursive_GOAd_phi_extraction(phiin,v,alpha,Pn,D,n,Nfin,phitable,errorvec,phivecin)
(phiin,v,alpha,Pn,D,n,Nfin,phitable,errorvec)
%recursive R function for globally optimal adaptive local measurements,
%returns the final success probability and the list of optimal angles

%phivec is a list of phi values, it is what we are optimising each step
%over

%phitable is the table of optimal phi values which have been found for the
%n+1 onwards values. So rather than optimising over all angles, we just
%look-up this table. 

%phivec is the list of error proabilities we are using, so we find the Pn
%closest to any value in this table

%v, alpha, Pn are parameters of the model

% D is the detection outcome; either 0 or 1

% n is the current stage

% Nfin is maximum number of stages

%assumes we always start at n=0, i.e. we are always using Higgins notation
%and calculating R0
  
if n==Nfin    
    %for kk=0:1
      %
        rout=min(Pn,1-Pn);
        phivec=phivecin;
    %end
elseif n~=0
    %if n is not 0 and not Nfin, we use the look-up table to determine the
    %appropriate phi value, based on the corresponding Pn value
    
    [minval,Ind]=min(abs(errorvec-Pn));
    
    %get the corresponding known phi values for each angle
    phivec_round=phitable(:,n);
    
    phi=phivec_round(Ind)
    Pnext0=pnplus1(phi,v,alpha,0,Pn);
    Pnext1=pnplus1(phi,v,alpha,1,Pn);
    
    rout = probD(phi,v,alpha,0,Pn)*R_recursive_GOAd_phi_extraction(phi,v,alpha,Pnext0,0,n+1,Nfin,phitable,errorvec,phivecin)+ probD(phi,v,alpha,1,Pn)*R_recursive_GOAd_phi_extraction(phi,v,alpha,Pnext1,1,n+1,Nfin,phitable,errorvec,phivecin);
elseif n==0
%else
   %want to optimise phi in here
   phi=phiin
    Pnext0=pnplus1(phi,v,alpha,0,Pn);
    Pnext1=pnplus1(phi,v,alpha,1,Pn);
    
    rout = probD(phi,v,alpha,0,Pn)*R_recursive_GOAd_phi_extraction(phi,v,alpha,Pnext0,0,n+1,Nfin,phitable,errorvec,phivecin)+ probD(phi,v,alpha,1,Pn)*R_recursive_GOAd_phi_extraction(phi,v,alpha,Pnext1,1,n+1,Nfin,phitable,errorvec,phivecin);

end
    
end