function rout= R_recursive_manual(phiin,v,alpha,Pn,D,n,Nfin)

%phiin is now a vector of phi values and I will just check every possible
%combination

%v, alpha, Pn are parameters of the model

% D is the detection outcome; either 0 or 1

% n is the current stage

% Nfin is maximum number of stages

%assumes we always start at n=0, i.e. we are always using Higgins notation
%and calculating R0
  
if n==Nfin    
    %for kk=0:1
      %
        rout=min(Pn,1-Pn);
        
    %end
elseif n==Nfin-1
    phi=0.5*acot((2*Pn-1)*cot(alpha));
    
     Pnext0=pnplus1(phi,v,alpha,0,Pn);
    Pnext1=pnplus1(phi,v,alpha,1,Pn);
    
    rout= probD(phi,v,alpha,0,Pn)*R_recursive_manual(phiin,v,alpha,Pnext0,0,n+1,Nfin)+ probD(phi,v,alpha,1,Pn)*R_recursive_manual(phiin,v,alpha,Pnext1,1,n+1,Nfin);
elseif n~=0
    
    phi=phiin(n+1+D);
    Pnext0=pnplus1(phi,v,alpha,0,Pn);
    Pnext1=pnplus1(phi,v,alpha,1,Pn);
    
    
    rout= probD(phi,v,alpha,0,Pn)*R_recursive_manual(phiin,v,alpha,Pnext0,0,n+1,Nfin)+ probD(phi,v,alpha,1,Pn)*R_recursive_manual(phiin,v,alpha,Pnext1,1,n+1,Nfin);
elseif n==0
    phi=phiin(n+1);
    Pnext0=pnplus1(phi,v,alpha,0,Pn);
    Pnext1=pnplus1(phi,v,alpha,1,Pn);
    
    rout= probD(phi,v,alpha,0,Pn)*R_recursive_manual(phiin,v,alpha,Pnext0,0,n+1,Nfin)+ probD(phi,v,alpha,1,Pn)*R_recursive_manual(phiin,v,alpha,Pnext1,1,n+1,Nfin);

    %if n=0, there is only one measurement angle
    
    % elseif n==0
%    %want to optimise phi in here
%    phi=phiin;
%     Pnext0=pnplus1(phi,v,alpha,0,Pn);
%     Pnext1=pnplus1(phi,v,alpha,1,Pn);
%     
%     rout= probD(phi,v,alpha,0,Pn)*R_recursive(phi,phiknown,v,alpha,Pnext0,0,n+1,Nfin)+ probD(phi,v,alpha,1,Pn)*R_recursive(phi,phiknown,v,alpha,Pnext1,1,n+1,Nfin);

end
    
end