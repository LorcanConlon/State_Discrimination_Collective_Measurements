function value=helstrom_check(rho1,rho2,Pn,n)
%just checking best way to write the helstrom bound
rho1in=rho1;
rho2in=rho2;
for kk=1:n
    
    if kk==n
        %project onto the positive part of the differential matrix once we
        %have the correct rhos
        Mp=Pn*rho1-(1-Pn)*rho2;
        value=Pn*(1-Pn)*trace(rho1*rho2);
        %Pn*trace(rho1*(eye(size(rho1))-Mp))+(1-Pn)*trace(rho2*Mp);
       % value=Pn-0.5*(1-Pn)*trace(sqrt(Mp*Mp'));
        %0.5*(1-trace(sqrtm(Mp*Mp')));
    else
        rho1=kron(rho1,rho1in);
        rho2=kron(rho2,rho2in);
    end
end