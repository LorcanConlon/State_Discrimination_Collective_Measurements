clear all
%close all
%we will only concern ourselves with N=2 for the time being and look at the
%final error probability for different starting priors.

Pnvec=linspace(0.5,0.999,1000);
%Pnvec=[0.87]
    nphi=2502;
    %how many phis do you want to use -- Higgins used 2501
tic
    Nfin=2;
    
    v=0.1;
    alpha=pi/4;
    %definesethe state
for PP=1:length(Pnvec)
PP

    Pn=Pnvec(PP);
    Pn=0.75;
    %initial prior

    %HELSTROM BOUND
    for ll=1:Nfin
        Helstrom_error(ll)=helstrom(rhoplus(v,alpha),rhominus(v,alpha),Pn,ll);
        Helstrom_error_2(ll)=helstrom_check(rhoplus(v,alpha),rhominus(v,alpha),Pn,ll);
    end
    Helstrom_save1(PP)=Helstrom_error(1);
    Helstrom_save(PP)=Helstrom_error(end);
    
    Helstrom_save_2(PP)=Helstrom_error_2(end);

    %LOCALLY OPTIMAL FIXED LOCAL MEASUREMENT
    %we find the phi which minimises the single copy P.O.E., then repeatedly
    %use that
    phivec=linspace(0,pi/2,nphi);
    for kk=1:length(phivec) 
        phi=phivec(kk);
        Perror(kk)=Pn*trace(Pi1(phi)*rhoplus(v,alpha))+(1-Pn)*trace(Pi0(phi)*rhominus(v,alpha));

    end
    Perrorlocal=min(Perror);
    Nfineff=Nfin;
    %for fixed local measurements an even number of copies performs identical
    %to an uneven no
    if ~mod(Nfin,2)
        Nfineff=Nfin-1;
    end
    Perrlocal_local=0;
    for n=0:floor(Nfineff/2)
        Perrlocal_local=Perrlocal_local+nchoosek(Nfineff,n)*(1-Perrorlocal)^n*(Perrorlocal)^(Nfineff-n);
    end
    
    LOF_save(PP)=Perrlocal_local(end);

    %GLOBALLY OPTIMAL FIXED LOCAL MEASUREMENT
    %initial phiknown is just random but after we will build it up

    minvalvec=[];
    for kk =1:Nfin
        %want to optimise each phi value
        for hh=1:length(phivec)
            phiin=phivec(hh);
            %valuesave(hh)=R_recursive(phiin,phiknown,v,alpha,Pn,233424234,0,kk);
            valuesave(hh)=R_recursive_GOF(phiin,v,alpha,Pn,678,0,kk);
        end

        [minval,opth]=min(valuesave);

    %     if kk==1
    %         phiknown=phivec(opth);
    %     else
    %         phiknown=[phivec(opth),phiknown];
    %     end
    phisave(kk)=phivec(opth);
        minvalvec(kk)=minval;

    %     plot(phivec,valuesave)
    %     yline(Pe1Helstrom)
    %     return
    end
    
    GOF_save(PP)=minvalvec(Nfin);

%     for kk=1:length(phisave)
%        if phisave(kk)<pi/4 
%           phisave(kk)=pi/2-phisave(kk) ;
%        end
%     end
%     hold on
%     plot(phisave)


    %LOCALLY OPTIMAL ADAPTIVE MEASUREMENT
    %using eq(4) of Higgins, we can get the optimal measurement given a certain
    %prior. (For pure states this should equal the Helstrom bound. Also appears to equal the Helstrom bound for mixed states)

    %In Higgin's paper Fig.8. shows how the GOF scheme outperforms the LOA
    %scheme sometimes, but for N=2 (where we will concern ourselves), this is
    %never true. 
    phiivec=[];
    for kk=1:Nfin

    %     phi=0.5*acot((2*q-1)*cot(alpha));
    %     phiivec=[phiivec,phi];
        %don't need to optimise the phi's in each stage, but we do need a new
        %recursive function which has a different phi value for each step
        Perror_local_adaptive(kk)=R_recursive_LOF(phiivec,v,alpha,Pn,678,0,kk);

    end

    LOAd_save(PP)=Perror_local_adaptive(end);

    
    
    %GLOBALLY OPTIMAL ADAPTIVE MEASUREMENT
    %this is how many different error probabilities and angles we will iterate over.
    %Higgins used ~ 50
    nsamp=nphi;
    eps=0.00001;
    PerrVec=linspace(0+eps,1-eps,nsamp);
    anglevec=linspace(0+eps,pi/2-eps,nsamp);

    %this is the repeating table of error probabilities on run to run
    Ertable=[];
    %Ertable=[PerrVec',PerrVec',PerrVec'];
    %table of optimal angles
    angletable=0*Ertable;

    %this is the actual table of how well the estimation scheme does
    ActualErtable=0*Ertable;

    minvalvec=[];
    for kk =1:Nfin
        %want to optimise each phi value
        Ertable=[Ertable,PerrVec'];
        if kk==1
            %in the first round the optimal angle for each Perr is just the
            %Helstrom angle
            for hh=1:length(PerrVec)
                errorProb=PerrVec(hh);
                optimalangle=0.5*acot((2*errorProb-1)*cot(alpha));
                anglevecopt(hh)=optimalangle;
                erInt=errorProb*trace(Pi1(optimalangle)*rhoplus(v,alpha))+(1-errorProb)*trace(Pi0(optimalangle)*rhominus(v,alpha));
                Perror_firstrun(hh)=min(erInt,1-erInt);
            end
            angletable=[anglevecopt',angletable];
            ActualErtable=[Perror_firstrun',ActualErtable];

            %for each angle we also want to do the optimisation for
            %errorProb=Pn, so that we can extract the ?

            errorProb=Pn;
            optimalangle=0.5*acot((2*errorProb-1)*cot(alpha));
            Perror_out(kk)=errorProb*trace(Pi1(optimalangle)*rhoplus(v,alpha))+(1-errorProb)*trace(Pi0(optimalangle)*rhominus(v,alpha));

        elseif kk~=Nfin
            %just first getting the value if we have this many copies
            errorProb=Pn;
            for ll=1:length(anglevec)
                 phiin=anglevec(ll);
                 valuesave(ll)=R_recursive_GOAd(phiin,v,alpha,errorProb,678,0,kk,angletable,PerrVec);
            end
            [minval_opt,indexx]=min(valuesave);
            Perror_out(kk)=minval_opt;

            for hh=1:length(PerrVec)
                errorProb=PerrVec(hh);
                for ll=1:length(anglevec)
                    phiin=anglevec(ll);
                    %valuesave(hh)=R_recursive(phiin,phiknown,v,alpha,Pn,233424234,0,kk);
                    valuesave(ll)=R_recursive_GOAd(phiin,v,alpha,errorProb,678,0,kk,angletable,PerrVec);
                end
                %for each error probability in the table, we want the angle
                %which minimises this
                [minval_opt,indexx]=min(valuesave);
                anglevecopt(hh)=anglevec(indexx);
                Perror_nthrun(hh)=minval_opt;
            end
            angletable=[anglevecopt',angletable];
            ActualErtable=[Perror_nthrun',ActualErtable];


        elseif kk==Nfin
            %now we only optimise over the known input error probability
                errorProb=Pn;
                for ll=1:length(anglevec)
                    phiin=anglevec(ll);
                    %valuesave(hh)=R_recursive(phiin,phiknown,v,alpha,Pn,233424234,0,kk);
                    valuesave(ll)=R_recursive_GOAd(phiin,v,alpha,errorProb,678,0,kk,angletable,PerrVec);
                end
                %for each error probability in the table, we want the angle
                %which minimises this
                [minval_opt,indexx]=min(valuesave);
                %anglevecopt(hh)=anglevec(indexx);
                Perror_nthrun(hh)=minval_opt;
            %Perrorfin_GOAd=minval_opt
            Perror_out(kk)=minval_opt;

        end
    end
    
    GOAd_save(PP)=minval_opt;
    
%     %NUMERICAL CHECK OF THE GOAD MEASUREMENT
%     for kk =1:length(phivec)
%         kk;
%         phiin1=phivec(kk);     
%         valuesave1(kk)=R_recursive_manual(phiin1,v,alpha,Pn,233424234,0,2);
%     end
%     
%     NUM_save(PP)=min(valuesave1);

GOAd_save
return
    
end

% GOAd_save
% Helstrom_save
% return
 %%
% close
%  Helstrom_save_2
%   Helstrom_save
%   return
if v==0.1 && alpha==pi/4
dataP=[0.6,0.66,0.702,0.73,0.75,0.77,0.82,0.85,0.87]
dataEr=[0.12796798,0.11811124299999999,0.1142766238,0.10636676600000002,0.09935548125,0.09577041549999998,0.08580677400000002,0.07694590500000001,0.07122451775000001]
errorb=[0.0007034918776247535,0.0006928083563957934,0.000639618895915582,0.0006628830204529001,0.0006186982300312086,0.0006120538647209409,0.0005718804023981239,0.0005441752449291957,0.0005183335425486181]
errorbar(dataP,dataEr,errorb,'x')
hold on
elseif v==0.15 && alpha==pi/4
  dataP=[0.6,0.65,0.7,0.75,0.8,0.85,0.9]
dataEr=[0.154,0.151,0.133,0.1197,0.103,0.0885,0]
errorb=[0.0007034918776247535,0.0006928083563957934,0.000639618895915582,0.0006628830204529001,0.0006186982300312086,0.0006120538647209409,0.0005718804023981239,0.0005441752449291957,0.0005183335425486181]
errorbar(dataP,dataEr,errorb,'x')
hold on  
elseif v==0.12 && alpha==pi/4
    
    dataP=[0.55,0.6,0.65,0.7,0.75,0.8,0.85];
    dataEr=[0.146,0.136,0.131,0.12,0.107,0.095,0.0837];
    plot(dataP,dataEr,'x')
    hold on
elseif v==0.08 && alpha==pi/4
     dataP=[0.55,0.6,0.65,0.7,0.725,0.75,0.775,0.8,0.85];
    dataEr=[0.127,0.118,0.11,0.105,0.102,0.0943,0.0899,0.083,0.0744];
    plot(dataP,dataEr,'x')
    hold on
elseif v==0.08 && alpha==pi/6
     dataP=[0.55,0.6,0.65,0.7,0.75,0.8,0.85,0.9,0.95];
    dataEr=[0.216,0.201,0.198,0.1777,0.1576,0.1366,0.1190,0.0875,0.054];
    plot(dataP,dataEr,'x')
    hold on
 elseif v==0.1 && alpha==pi/6
     dataP=[0.55,0.6,0.65,0.7,0.725,0.75,0.775,0.8,0.85];
    dataEr=[0.127,0.118,0.11,0.105,0.102,0.0943,0.0899,0.083,0.0744];
    plot(dataP,dataEr,'x')
    hold on
elseif v==0.12 && alpha==pi/6
     dataP=[0.55,0.6,0.65,0.7,0.725,0.75,0.775,0.8,0.85];
    dataEr=[0.127,0.118,0.11,0.105,0.102,0.0943,0.0899,0.083,0.0744];
    plot(dataP,dataEr,'x')
    hold on
end
plot(Pnvec,Helstrom_save)

hold on
plot(Pnvec,GOAd_save)

delta=GOAd_save-Helstrom_save;
figure(2)
plot(Pnvec,delta)

%numerically checking the optimality of my GOAD code
% num_check=NUM_save-GOAd_save;
% figure(3)
% plot(Pnvec,num_check)
toc

dlmwrite('exported_data_delta/delta2_2501_1000_v8_pi6_helstrom.csv',Helstrom_save, 'delimiter', ',', 'precision', 9);
dlmwrite('exported_data_delta/delta2_2501_1000_v8_pi6_GOAD.csv',GOAd_save, 'delimiter', ',', 'precision', 9);
%plot(Pnvec,LOAd_saveGOAd_save,'o')
%plot(Pnvec,GOF_save,'x')
%plot(Pnvec,LOF_save,'.')
%plot(Pnvec,NUM_save,'P')

%%
return
dlmwrite('exported_data_delta/delta2.csv',delta, 'delimiter', ',', 'precision', 9);
dlmwrite('exported_data_v08_api6/twocopy_v08_alpi6_2501.csv',Helstrom_save, 'delimiter', ',', 'precision', 9);
dlmwrite('exported_data_v08_api6/singlecopy_v08_alpi6_2501.csv',GOAd_save, 'delimiter', ',', 'precision', 9);
return
figure(2)

plot(Pnvec,Helstrom_save./GOAd_save)
hold on
plot(Pnvec,Helstrom_save./Helstrom_save1,'o')

[mval,ind]=max(GOAd_save-Helstrom_save)
[mval,ind]=min(Helstrom_save./GOAd_save)