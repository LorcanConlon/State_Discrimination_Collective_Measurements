clear all
close all
%just a numerical check of the delta fig for 2 and 3 copies

%2-copy needs three diff angles
%3-copy needs 7

%using helstrom angle, 2-copy needs 1 and 3-copy needs 3

Pnvec=linspace(0.5,0.95,20);
%Pnvec=[0.87]
    nphi=201;
    phivec=linspace(0,pi/2,nphi);
    %how many phis do you want to use -- Higgins used 2501
    %for three copies we can use 100 to get a rough estimate of the optimal
    %phis and then fine tune, fine tune, fine tune
    
    

    Nfin=3;
    
    three_copy='yes';
    two_copy='noo';
    v=0.1;
    alpha=pi/4;
    %definesethe state
for PP=1:length(Pnvec)
PP

    Pn=Pnvec(PP);
    
    %initial prior

    %HELSTROM BOUND
    Helstrom_error_1(PP)=helstrom(rhoplus(v,alpha),rhominus(v,alpha),Pn,1);
    Helstrom_error_2(PP)=helstrom(rhoplus(v,alpha),rhominus(v,alpha),Pn,2);
    Helstrom_error_3(PP)=helstrom(rhoplus(v,alpha),rhominus(v,alpha),Pn,3);
    
    
    if two_copy=='yes'
    %two copies first
    for hh=1:nphi
        phi1=phivec(hh);
        
        %checking single copy first
        %two possible posteriors for each outcome
        Pnext0=pnplus1(phi1,v,alpha,0,Pn);
        Pnext1=pnplus1(phi1,v,alpha,1,Pn);
        %error probability is the probability of each outcome
        prob0=probD(phi1,v,alpha,0,Pn);
        prob1=probD(phi1,v,alpha,1,Pn);
        %times the minimum of the new posterior or 1-new posterior
        minval0=min(Pnext0,1-Pnext0);
        minval1=min(Pnext1,1-Pnext1);
        Perror1copy(hh)=prob0*minval0+prob1*minval1;
        
        
        %based on the two outcomes above, there are two optimal angles for
        %the second measurement in the two copy case
        optimalangle0=0.5*acot((2*Pnext0-1)*cot(alpha));
        optimalangle1=0.5*acot((2*Pnext1-1)*cot(alpha));
        
        %which gives the four possible posteriors
        Pnext00=pnplus1(optimalangle0,v,alpha,0,Pnext0);
        Pnext01=pnplus1(optimalangle0,v,alpha,1,Pnext0);
        Pnext10=pnplus1(optimalangle1,v,alpha,0,Pnext1);
        Pnext11=pnplus1(optimalangle1,v,alpha,1,Pnext1);
        
        %the probability of obtaining each posterior
        prob00=prob0*probD(optimalangle0,v,alpha,0,Pnext0);
        prob01=prob0*probD(optimalangle0,v,alpha,1,Pnext0);
        prob10=prob1*probD(optimalangle1,v,alpha,0,Pnext1);
        prob11=prob1*probD(optimalangle1,v,alpha,1,Pnext1);
        
         %times the minimum of the new posterior or 1-new posterior
        minval00=min(Pnext00,1-Pnext00);
        minval01=min(Pnext01,1-Pnext01);
        minval10=min(Pnext10,1-Pnext10);
        minval11=min(Pnext11,1-Pnext11);
        
    error(hh)=prob00*minval00+prob01*minval01+prob10*minval10+prob11*minval11;
    
    end
     [error_LOCC(PP),inde]=min(error);
    opt_phi(PP)=phivec(inde);
    one_copy_LOCC(PP)=min(Perror1copy);
    end
        
    if three_copy=='yes'
    count=0;
    clear error_alt
      for hh=1:nphi
          %first measurement
          phi1=phivec(hh);
          for gg=1:nphi
              %second measurement if outcome 0 clicks
              phi2=phivec(gg);
              for ii=1:nphi
                  count=count+1;
                  %second measurement if outcome 1 clicks
                  phi3=phivec(ii);
                  
                  %two possible posteriors for the first measurement
                  %outcomes
                  Pnext0=pnplus1(phi1,v,alpha,0,Pn);
                  Pnext1=pnplus1(phi1,v,alpha,1,Pn);
                  % probability of the two first measurement outcomes
                  prob0=probD(phi1,v,alpha,0,Pn);
                  prob1=probD(phi1,v,alpha,1,Pn);
                  %and then four possible posteriors after the second
                  %measurement
                  Pnext00=pnplus1(phi2,v,alpha,0,Pnext0);
                  Pnext01=pnplus1(phi2,v,alpha,1,Pnext0);
                  Pnext10=pnplus1(phi3,v,alpha,0,Pnext1);
                  Pnext11=pnplus1(phi3,v,alpha,1,Pnext1);
                  %the probability of obtaining each pair of measurement
                  %results
                  prob00=prob0*probD(phi2,v,alpha,0,Pnext0);
                  prob01=prob0*probD(phi2,v,alpha,1,Pnext0);
                  prob10=prob1*probD(phi3,v,alpha,0,Pnext1);
                  prob11=prob1*probD(phi3,v,alpha,1,Pnext1);
                  
                  %for each pair of results there is then an optimal angle
                  %for the final measurement based on the posterior prob
                  optimalangle00=0.5*acot((2*Pnext00-1)*cot(alpha));
                  optimalangle01=0.5*acot((2*Pnext01-1)*cot(alpha));
                  optimalangle10=0.5*acot((2*Pnext10-1)*cot(alpha));
                  optimalangle11=0.5*acot((2*Pnext11-1)*cot(alpha));
                  
                  %we then construct the 8 possible posteriors
                  Pnext000=pnplus1(optimalangle00,v,alpha,0,Pnext00);
                  Pnext001=pnplus1(optimalangle00,v,alpha,1,Pnext00);
                  Pnext010=pnplus1(optimalangle01,v,alpha,0,Pnext01);
                  Pnext011=pnplus1(optimalangle01,v,alpha,1,Pnext01);
                  Pnext100=pnplus1(optimalangle10,v,alpha,0,Pnext10);
                  Pnext101=pnplus1(optimalangle10,v,alpha,1,Pnext10);
                  Pnext110=pnplus1(optimalangle11,v,alpha,0,Pnext11);
                  Pnext111=pnplus1(optimalangle11,v,alpha,1,Pnext11);
                 
                  
                  %which occur with probability
                  prob000=prob00*probD(optimalangle00,v,alpha,0,Pnext00);
                  prob001=prob00*probD(optimalangle00,v,alpha,1,Pnext00);
                  prob010=prob01*probD(optimalangle01,v,alpha,0,Pnext01);
                  prob011=prob01*probD(optimalangle01,v,alpha,1,Pnext01);
                  prob100=prob10*probD(optimalangle10,v,alpha,0,Pnext10);
                  prob101=prob10*probD(optimalangle10,v,alpha,1,Pnext10);
                  prob110=prob11*probD(optimalangle11,v,alpha,0,Pnext11);
                  prob111=prob11*probD(optimalangle11,v,alpha,1,Pnext11);
    
                  minval000=min(Pnext000,1-Pnext000);
                  minval001=min(Pnext001,1-Pnext001);
                  minval010=min(Pnext010,1-Pnext010);
                  minval011=min(Pnext011,1-Pnext011);
                  minval100=min(Pnext100,1-Pnext100);
                  minval101=min(Pnext101,1-Pnext101);
                  minval110=min(Pnext110,1-Pnext110);
                  minval111=min(Pnext111,1-Pnext111);
                  
                  error3(count)=prob000*minval000+prob001*minval001+prob010*minval010+prob011*minval011+prob100*minval100+prob101*minval101+prob110*minval110+prob111*minval111;
                  
                  angle_save{count}=[phi1,phi2,phi3];
              end
          end
      end
    [three_copy_LOCC(PP),ind3]=min(error3);
    angles=angle_save{ind3};
    angle1save(PP)=angles(1);
    angle2save(PP)=angles(2);
    angle3save(PP)=angles(3);
    end
    
   
    
    %[two_copy_LOCC_bash(PP),ind]=min(error_alt);

    
end

if two_copy=='yes'
    delta=error_LOCC-Helstrom_error_2;
plot(Pnvec,Helstrom_error_2,'o')

hold on
plot(Pnvec,error_LOCC)


figure(2)
plot(Pnvec,delta)

figure(4)
plot(Pnvec,opt_phi)
end
if three_copy=='yes'
    
    figure(1)
   plot(Pnvec,Helstrom_error_3,'x')
   hold on
   plot(Pnvec,three_copy_LOCC,'-x')
   
   delta3=three_copy_LOCC-Helstrom_error_3;
   figure(2)
   hold on
plot(Pnvec,delta3)
figure(3)
plot(Pnvec,angle1save,'-o')
hold on
plot(Pnvec,angle2save,'-x')
plot(Pnvec,angle3save,'-.')
end

%plot(Pnvec,two_copy_LOCC_bash,'x')

%delta=two_copy_LOCC_bash-Helstrom_error_2;


%delta1=one_copy_LOCC-Helstrom_error_1


dlmwrite('exported_data_delta/delta3_201_angle1.csv',angle1save, 'delimiter', ',', 'precision', 9);
dlmwrite('exported_data_delta/delta3_201_angle2.csv',angle2save, 'delimiter', ',', 'precision', 9);
dlmwrite('exported_data_delta/delta3_201_angle3.csv',angle3save, 'delimiter', ',', 'precision', 9);


