clear all
close all
%just a numerical check of the delta fig for 2 and 3 copies

%2-copy needs three diff angles
%3-copy needs 7

%using helstrom angle, 2-copy needs 1 and 3-copy needs 3

Pnvec=linspace(0.55,0.95,20);
%Pnvec=[0.87]
    nphi=2501;
    phivec=linspace(0,2*pi,nphi);
    %how many phis do you want to use -- Higgins used 2501
    
    

    Nfin=3;
    
    v=0.1;
    alpha=pi/4;
    Pn=0.5
        
        optimalangle0=0.5*acot((2*Pn-1)*cot(alpha));
        
        %probabilities
        trace(rhoplus(v,alpha)*Pi0(optimalangle0))
        trace(rhominus(v,alpha)*Pi0(optimalangle0))
        return
        
        %probability of the POVM outcome 0 on both new POVMS
        prob0POVM0=Pn0*trace(rhoplus(v,alpha)*Pi0(optimalangle0))+(1-Pn0)*trace(rhominus(v,alpha)*Pi0(optimalangle0));
        prob0POVM1=Pn1*trace(rhoplus(v,alpha)*Pi0(optimalangle1))+(1-Pn1)*trace(rhominus(v,alpha)*Pi0(optimalangle1));
        %probability of the POVM outcome 1 on both new POVMS
        prob1POVM0=Pn0*trace(rhoplus(v,alpha)*Pi1(optimalangle0))+(1-Pn0)*trace(rhominus(v,alpha)*Pi1(optimalangle0));
        prob1POVM1=Pn1*trace(rhoplus(v,alpha)*Pi1(optimalangle1))+(1-Pn1)*trace(rhominus(v,alpha)*Pi1(optimalangle1));
        
        %posterior (q) given all 4 POVM outcome
        %0 clicked at first POVM
        Pn00=Pn0*trace(rhoplus(v,alpha)*Pi0(optimalangle0))/prob0POVM0;
        Pn01=(1-Pn0)
        %1 clicked at first POVM
        Pn1=Pn*trace(rhoplus(v,alpha)*Pi1(phi1))/prob0;
        
        

plot(Pnvec,Helstrom_save)

hold on
plot(Pnvec,GOAd_save)

delta=GOAd_save-Helstrom_save;
figure(2)
plot(Pnvec,delta)

%numerically checking the optimality of my GOAD code
num_check=NUM_save-GOAd_save;
figure(3)
plot(Pnvec,num_check)

