%fmincon to minimise the state discrimination error
%will use model of form predicted=M*measured

%from state 1
% pred1=[721.6113000000033,16678.5098,68945.90449999999,13653.974400000003];
% meas1=[1754.919800000003,17946.115,65730.3069,14568.658300000003];
%v=0.1, Pn=0.75, alpha=pi/4
pred1=[4042.7675, 5981.174999999999, 12468.4825, 77507.575];
meas1=[4271.375, 7393.094999999999, 12388.755, 75946.775];

%from state 2
% pred2=[26065.592,4568.867500000002,51494.3928,17871.1477];
% meas2=[25767.610300000004,5787.6370000000015,49694.0766,18750.6761];
%v=0.1, Pn=0.75, alpha=pi/4
pred2=[76161.23, 4240.5825, 1261.1425, 18337.045];
meas2=[72751.72, 5913.27, 2223.6475, 19111.3625];
      
fun=@(x)Perr(pred1,meas1,pred2,meas2,x)

x0 = rand(1,12);
x0=[1,0,0,0,1,0,0,0,1,0,0,0]

% Perr(pred1,meas1,pred2,meas2,x0)
% return
Perr(pred1,meas1,pred2,meas2,x0);
A = [1,1,1,0,0,0,0,0,0,0,0,0;
     0,0,0,1,1,1,0,0,0,0,0,0;
     0,0,0,0,0,0,1,1,1,0,0,0;
     0,0,0,0,0,0,0,0,0,1,1,1];
b = [1,1,1,1];
lb=[0,0,0,0,0,0,0,0,0,0,0,0];
lb=[0.9,0,0,0,0.9,0,0,0,0.9,0,0,0,0,0,0,0]
ub=[1,1,1,1,1,1,1,1,1,0.1,0.1,0.1];
x = fmincon(fun,x0,A,b,[],[],lb,ub)


[err,M]=Perr(pred1,meas1,pred2,meas2,x)
return
Perr(pred1,meas1,pred2,meas2,[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1])


[out1,out2]=newvals(pred1,meas1,pred2,meas2,x)

0.95*out1(1)/sum(out1)+0.05*(out2(2)+out2(3)+out2(4))/sum(out2)

function [error,M]=Perr(pred1,meas1,pred2,meas2,X)

M=[X(1),X(2),X(3),1-X(1)-X(2)-X(3);
   X(4),X(5),X(6),1-X(4)-X(5)-X(6);
   X(7),X(8),X(9),1-X(7)-X(8)-X(9);
   X(10),X(11),X(12),1-X(10)-X(11)-X(12);];


% out1=inv(M)*meas1';
% out2=inv(M)*meas2';
out1=M*meas1';
out2=M*meas2';


%error=sum(abs(true1-meas1'))+sum(abs(true2-meas2'));

error=0.75*out1(1)/sum(out1)+0.25*(out2(2)+out2(3)+out2(4))/sum(out2);
end


function [out1,out2]=newvals(pred1,meas1,pred2,meas2,X)

M=[X(1),X(2),X(3),1-X(1)-X(2)-X(3);
   X(4),X(5),X(6),1-X(4)-X(5)-X(6);
   X(7),X(8),X(9),1-X(7)-X(8)-X(9);
   X(10),X(11),X(12),1-X(10)-X(11)-X(12);];


out1=inv(M)*meas1';
out2=inv(M)*meas2';

end
