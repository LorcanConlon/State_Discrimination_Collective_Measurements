function prob=pmeasDstatem(phi,v,alpha,D)

% if D==0
% prob=trace(rhominus(v,alpha)*Pi0(phi));%+trace(rhominus(v,alpha)*Pi0(phi));
% %prob=0.5*v+(1-v)*cos(phi-(pi/4)*(D-1)+alpha/2)^2;
% elseif D==1
% prob=trace(rhominus(v,alpha)*Pi1(phi));%+trace(rhominus(v,alpha)*Pi1(phi)); 
% end
D=-2*D+1;
prob=0.5*v+(1-v)*cos(phi-(pi/4)*(D-1)+alpha/2)^2;