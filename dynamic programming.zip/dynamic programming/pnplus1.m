function pout=pnplus1(phi,v,alpha,D,Pn)

pout=Pn*pmeasDstatep(phi,v,alpha,D)/probD(phi,v,alpha,D,Pn);