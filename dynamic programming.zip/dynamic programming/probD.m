function prob=probD(phi,v,alpha,D,Pn)

prob=Pn*pmeasDstatep(phi,v,alpha,D)+(1-Pn)*pmeasDstatem(phi,v,alpha,D);
