function rho=rhoplus(v,alpha)

rho=0.5*(eye(2)+(1-v)*(pauli(3)*cos(alpha)+pauli(1)*sin(alpha)));