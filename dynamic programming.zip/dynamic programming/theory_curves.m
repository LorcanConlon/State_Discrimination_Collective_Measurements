% theoretical curves for state discrimination
return
POVM = readmatrix('exported_data/v02Pn95_POVMs.txt')
Xvec = readmatrix('exported_data/v02Pn95_Xvec.txt')

Pi1=POVM(:,1)*POVM(:,1)';
Pi2=POVM(:,2)*POVM(:,2)';
Pi3=POVM(:,3)*POVM(:,3)';
Pi4=POVM(:,4)*POVM(:,4)';

Pi1+Pi2+Pi3+Pi4
v=0.02;
alphavec=linspace(0.01,pi/4,10);

for kk=1:length(alphavec)
    rho1=rhoplus(v,alphavec(kk));
    rho2=rhominus(v,alphavec(kk));
    
    p00_1(kk)=trace(kron(rho1,rho1)*Pi1);
    p01_1(kk)=trace(kron(rho1,rho1)*Pi2);
    p10_1(kk)=trace(kron(rho1,rho1)*Pi3);
    p11_1(kk)=trace(kron(rho1,rho1)*Pi4);
    
    p00_2(kk)=trace(kron(rho2,rho2)*Pi1);
    p01_2(kk)=trace(kron(rho2,rho2)*Pi2);
    p10_2(kk)=trace(kron(rho2,rho2)*Pi3);
    p11_2(kk)=trace(kron(rho2,rho2)*Pi4);
    
end

plot(p00_1)
hold on
plot(p01_1)
plot(p10_1)
plot(p11_1)

figure(2)
plot(p00_2)
hold on
plot(p01_2)
plot(p10_2)
plot(p11_2)

figure(3)

plot(p00_1)
hold on
plot(p00_2)

figure(4)

plot(p01_1)
hold on
plot(p01_2)

figure(5)

plot(p10_1)
hold on
plot(p10_2)