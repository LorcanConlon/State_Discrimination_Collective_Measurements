clear all
angles1=csvread('exported_data_delta/delta3_201_angle1.csv');
angles2=csvread('exported_data_delta/delta3_201_angle2.csv');
angles3=csvread('exported_data_delta/delta3_201_angle3.csv');

Pnvec=linspace(0.5,0.95,20);
    %for hh=1:length(Pnvec)
    hh=10;
    v=0.1;
    alpha=pi/4;
    Pn=Pnvec(hh);
    phi1=angles1(hh);
    phi2=angles2(hh);
    phi3=angles3(hh);
    %two possible posteriors for the first measurement
    %outcomes
    Pnext0=pnplus1(phi1,v,alpha,0,Pn);
    Pnext1=pnplus1(phi1,v,alpha,1,Pn);
    % probability of the two first measurement outcomes
    prob0=probD(phi1,v,alpha,0,Pn);
    return
    prob1=probD(phi1,v,alpha,1,Pn);
    %and then four possible posteriors after the second
    %measurement
    Pnext00=pnplus1(phi2,v,alpha,0,Pnext0);
    Pnext01=pnplus1(phi2,v,alpha,1,Pnext0);
    Pnext10=pnplus1(phi3,v,alpha,0,Pnext1);
    Pnext11=pnplus1(phi3,v,alpha,1,Pnext1);
    %the probability of obtaining each pair of measurement
    %results
    prob00=prob0*probD(phi2,v,alpha,0,Pnext0);
    return
    prob01=prob0*probD(phi2,v,alpha,1,Pnext0);
    prob10=prob1*probD(phi3,v,alpha,0,Pnext1);
    prob11=prob1*probD(phi3,v,alpha,1,Pnext1);

    %for each pair of results there is then an optimal angle
    %for the final measurement based on the posterior prob
    optimalangle00=0.5*acot((2*Pnext00-1)*cot(alpha));
    optimalangle01=0.5*acot((2*Pnext01-1)*cot(alpha));
    optimalangle10=0.5*acot((2*Pnext10-1)*cot(alpha));
    optimalangle11=0.5*acot((2*Pnext11-1)*cot(alpha));

    %we then construct the 8 possible posteriors
    Pnext000=pnplus1(optimalangle00,v,alpha,0,Pnext00);
    Pnext001=pnplus1(optimalangle00,v,alpha,1,Pnext00);
    Pnext010=pnplus1(optimalangle01,v,alpha,0,Pnext01);
    Pnext011=pnplus1(optimalangle01,v,alpha,1,Pnext01);
    Pnext100=pnplus1(optimalangle10,v,alpha,0,Pnext10);
    Pnext101=pnplus1(optimalangle10,v,alpha,1,Pnext10);
    Pnext110=pnplus1(optimalangle11,v,alpha,0,Pnext11);
    Pnext111=pnplus1(optimalangle11,v,alpha,1,Pnext11);


    %which occur with probability
    prob000=prob00*probD(optimalangle00,v,alpha,0,Pnext00);
    probD(optimalangle00,v,alpha,0,Pnext00)
    prob00
    return
    prob001=prob00*probD(optimalangle00,v,alpha,1,Pnext00);
    prob010=prob01*probD(optimalangle01,v,alpha,0,Pnext01);
    prob011=prob01*probD(optimalangle01,v,alpha,1,Pnext01);
    prob100=prob10*probD(optimalangle10,v,alpha,0,Pnext10);
    prob101=prob10*probD(optimalangle10,v,alpha,1,Pnext10);
    prob110=prob11*probD(optimalangle11,v,alpha,0,Pnext11);
    prob111=prob11*probD(optimalangle11,v,alpha,1,Pnext11);


    minval000=min(Pnext000,1-Pnext000);
    minval001=min(Pnext001,1-Pnext001);
    minval010=min(Pnext010,1-Pnext010);
    minval011=min(Pnext011,1-Pnext011);
    minval100=min(Pnext100,1-Pnext100);
    minval101=min(Pnext101,1-Pnext101);
    minval110=min(Pnext110,1-Pnext110);
    minval111=min(Pnext111,1-Pnext111);

    prob000*minval000
    prob001*minval001
    prob010*minval010

    prob011*minval011
    prob100*minval100
    prob101*minval101
    prob110*minval110
    prob111*minval111


    error3=prob000*minval000+prob001*minval001+prob010*minval010+prob011*minval011+prob100*minval100+prob101*minval101+prob110*minval110+prob111*minval111
    