%just want to look briefly at the structure of the two copy measurements
    Nfin=2;
    
    v=0.1;
    alpha=pi/4;
    
    Pn=0.75;
    
    Helstrom_error1=helstrom(rhoplus(v,alpha),rhominus(v,alpha),Pn,1);
    Helstrom_error=helstrom(rhoplus(v,alpha),rhominus(v,alpha),Pn,Nfin);
    Helstrom_error3=helstrom(rhoplus(v,alpha),rhominus(v,alpha),Pn,3);
    Helstrom_error4=helstrom(rhoplus(v,alpha),rhominus(v,alpha),Pn,4);
    
    rhop2=kron(rhoplus(v,alpha),rhoplus(v,alpha));
    rhom2=kron(rhominus(v,alpha),rhominus(v,alpha));
    rhop3=kron(rhop2,rhoplus(v,alpha));
    rhom3=kron(rhom2,rhominus(v,alpha));
    rhop4=kron(rhop3,rhoplus(v,alpha));
    rhom4=kron(rhom3,rhominus(v,alpha));
[Pe1,Pe2,povmN0,povmN1,povmN2,povmN3,sol]  = state_disc4(rhop2,rhom2,Pn,1-Pn);

Helstrom_error
Pe1+Pe2
%%

% [Pe1copy3,Pe2copy3,povmN0,povmN1,povmN2,povmN3,povmN4,povmN5,povmN6,povmN7,sol]  = state_disc8(rhop3,rhom3,Pn,1-Pn);
% Helstrom_error3
% Pe1copy3+Pe2copy3

% [Pe1copy4,Pe2copy4,povmNVec,sol] = state_disc_4copy(rhop4,rhom4,Pn,1-Pn);
% Pe1copy4+Pe2copy4
% Helstrom_error4
% % povmN0*povmN0'+povmN1*povmN1'+povmN2*povmN2'+povmN3*povmN3'+povmN4*povmN4'+povmN5*povmN5'+povmN6*povmN6'+povmN7*povmN7'
% % 
% 
% povmN0=povmNVec(:,1)
% povmN1=povmNVec(:,2)
% povmN2=povmNVec(:,3)
% povmN3=povmNVec(:,4)
% povmN4=povmNVec(:,5)
% povmN5=povmNVec(:,6)
% povmN6=povmNVec(:,7)
% povmN7=povmNVec(:,8)
% povmN8=povmNVec(:,9)
% povmN9=povmNVec(:,10)
% povmN10=povmNVec(:,11)
% povmN11=povmNVec(:,12)
% povmN12=povmNVec(:,13)
% povmN13=povmNVec(:,14)
% povmN14=povmNVec(:,15)
% povmN15=povmNVec(:,16)
%are they projectors


diag=csvread('exported_data_v1_api4/v1Pn75Alppiover4_POVMs_4copy.csv')
povmNVec=diag;
povmN0=povmNVec(:,1)
povmN1=povmNVec(:,2)
povmN2=povmNVec(:,3)
povmN3=povmNVec(:,4)
povmN4=povmNVec(:,5)
povmN5=povmNVec(:,6)
povmN6=povmNVec(:,7)
povmN7=povmNVec(:,8)
povmN8=povmNVec(:,9)
povmN9=povmNVec(:,10)
povmN10=povmNVec(:,11)
povmN11=povmNVec(:,12)
povmN12=povmNVec(:,13)
povmN13=povmNVec(:,14)
povmN14=povmNVec(:,15)
povmN15=povmNVec(:,16)
% %%
[trace(rhop4*povmN0*povmN0'),trace(rhop4*povmN1*povmN1'),trace(rhop4*povmN2*povmN2'),trace(rhop4*povmN3*povmN3'),trace(rhop4*povmN4*povmN4'),trace(rhop4*povmN5*povmN5'),trace(rhop4*povmN6*povmN6'),trace(rhop4*povmN7*povmN7')]
[trace(rhom4*povmN0*povmN0'),trace(rhom4*povmN1*povmN1'),trace(rhom4*povmN2*povmN2'),trace(rhom4*povmN3*povmN3'),trace(rhom4*povmN4*povmN4'),trace(rhom4*povmN5*povmN5'),trace(rhom4*povmN6*povmN6'),trace(rhom4*povmN7*povmN7')]

r0=rhop4;
r1=rhom4;
pi0=Pn;
pi1=1-Pn;
e1=pi0*(povmN0'*r0*povmN0+povmN1'*r0*povmN1+povmN2'*r0*povmN2+povmN3'*r0*povmN3+povmN4'*r0*povmN4+povmN5'*r0*povmN5+povmN6'*r0*povmN6+povmN7'*r0*povmN7);
e2=pi1*(povmN8'*r1*povmN8+povmN9'*r1*povmN9+povmN10'*r1*povmN10+povmN11'*r1*povmN11+povmN12'*r1*povmN12+povmN13'*r1*povmN13+povmN14'*r1*povmN14+povmN15'*r1*povmN15);
e1+e2

return
diag=[povmN0,povmN1,povmN2,povmN3,povmN4,povmN5,povmN6,povmN7,povmN8,povmN9,povmN10,povmN11,povmN12,povmN13,povmN14,povmN15];
diag'*diag

% %the unitary we need is therefore diag'
% 
% 
% dlmwrite('exported_data_v1_api4/v1Pn75Alppiover4_POVMs_3copy_take9_check.csv',diag, 'delimiter', ',', 'precision', 9);
% 
% %%
[trace(rhop3*povmN0*povmN0'),trace(rhop3*povmN1*povmN1'),trace(rhop3*povmN2*povmN2'),trace(rhop3*povmN3*povmN3'),trace(rhop3*povmN4*povmN4'),trace(rhop3*povmN5*povmN5'),trace(rhop3*povmN6*povmN6'),trace(rhop3*povmN7*povmN7')]
[trace(rhom3*povmN0*povmN0'),trace(rhom3*povmN1*povmN1'),trace(rhom3*povmN2*povmN2'),trace(rhom3*povmN3*povmN3'),trace(rhom3*povmN4*povmN4'),trace(rhom3*povmN5*povmN5'),trace(rhom3*povmN6*povmN6'),trace(rhom3*povmN7*povmN7')]

r0=rhop3;
r1=rhom3;
pi0=Pn;
pi1=1-Pn;
e1=pi0*(povmN0'*r0*povmN0+povmN1'*r0*povmN1+povmN2'*r0*povmN2+povmN3'*r0*povmN3);
e2=pi1*(povmN4'*r1*povmN4+povmN5'*r1*povmN5+povmN6'*r1*povmN6+povmN7'*r1*povmN7);
e1+e2
return

% Pe1
% Pe2
%     Helstrom_error
%     Helstrom_error1

    
%     va=0.1;
%     rhp2a=kron(rhoplus(va,alpha),rhoplus(va,alpha));
%     rhm2a=kron(rhominus(va,alpha),rhominus(va,alpha));
%      
%     trace(rhp2a*povmN0*povmN0')*Pn+trace(rhm2a*(eye(4)-povmN0*povmN0'))*(1-Pn)
%     
    
    povmN0*povmN0'
    
    povmN0*povmN0'+povmN1*povmN1'+povmN2*povmN2'+povmN3*povmN3'
    
    POVMs=[povmN0,povmN1,povmN2,povmN3];
    
    %POVMs' should diagonalise POVMs
    POVMs'*POVMs;
    fun=@(x) sum(sum(abs(U2a(x)-POVMs')))
x0=rand(1,16);
%x0=[1.332047066929274, 0.674434373615608, 1.342573324008889,1.332047081999419, 0.896361779524331, 0.228222830422120]
%U2a(x0)
%nonlincon=@nonlinfun

opts=optimoptions('fmincon','Display','iter','Algorithm','sqp','MaxIterations',1e5,'MaxFunctionEvaluations',1e6,'StepTolerance',1e-20);

%x=fmincon(fun,x0,[],[],[],[],[],[],nonlincon,opts)

x=fmincon(fun,x0,[],[],[],[],[],[],[],opts);

format short
U2a(x)-POVMs'

x
return
%%
format long
dlmwrite('exported_data_v12_api6/v12Pn95Alppiover6_POVMs.txt',POVMs, 'delimiter', ',', 'precision', 9);
dlmwrite('exported_data_v12_api6/v12Pn95Alppiover6_Xvec.txt',x, 'delimiter', ',', 'precision', 9);
return
    
        %NUMERICAL GOAD MEASUREMENT
        phivec=linspace(0,pi/2,1000);
    for kk =1:length(phivec)
        kk;
        phiin1=phivec(kk);     
        valuesave1(kk)=R_recursive_manual(phiin1,v,alpha,Pn,233424234,0,2);
    end
    
    NUM_save=min(valuesave1)